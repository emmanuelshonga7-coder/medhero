# medHero by Shonga

AI-powered medical flashcard app for Surgery, Paediatrics, Obs & Gynae, and Internal Medicine.

## Deploy to Vercel (Free)

### Step 1 — Get the code on GitHub
1. Go to [github.com](https://github.com) and create a free account (if you don't have one)
2. Click **New repository** → name it `medhero` → click **Create repository**
3. Upload all the files from this folder by clicking **uploading an existing file**

### Step 2 — Deploy on Vercel
1. Go to [vercel.com](https://vercel.com) and sign up with your GitHub account
2. Click **Add New Project**
3. Select your `medhero` repository
4. Click **Deploy** — Vercel does the rest automatically

### Step 3 — Add your API Key
After deploying, go to your project on Vercel:
1. Click **Settings** → **Environment Variables**
2. Add: `REACT_APP_ANTHROPIC_KEY` = your Anthropic API key
3. Redeploy

> **Get an API key:** Sign up at [console.anthropic.com](https://console.anthropic.com)

Your site will be live at `https://medhero.vercel.app` (or similar) — share with friends!

## Local Development

```bash
npm install
npm start
```
